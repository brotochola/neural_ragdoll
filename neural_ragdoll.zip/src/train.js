import { Worker } from 'worker_threads';
import { cpus } from 'os';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import * as B from './phys.js';
import { createSim, NW, H, NI, O, rngMk, netsFromCkpt, padWeights } from './core.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, '..');
const CKPT = path.join(ROOT, 'checkpoint.json');
const WEIGHTS = path.join(ROOT, 'weights.json');
const LOG = path.join(ROOT, 'train.log');

const args = process.argv.slice(2);
const flags = new Set(args);
const evalOnly = flags.has('--eval');
const resetGetup = flags.has('--reset-getup');
const resume = !flags.has('--fresh') && fs.existsSync(CKPT);
const maxGenArg = args.find((a, i) => args[i - 1] === '--gens');
const maxGens = maxGenArg && +maxGenArg > 0 ? +maxGenArg : Infinity;
const K = Math.max(1, Math.min(cpus().length - 2, +(process.env.WORKERS || (cpus().length - 2))));
const NP = 24;

const S = createSim(B, { seed: 7 });
S.setRng(Date.now() & 0xffff);

function log(s) {
  const line = `[${new Date().toISOString()}] ${s}`;
  console.log(line);
  fs.appendFileSync(LOG, line + '\n');
}

const arr5 = a => a ? Array.from(a, x => +x.toFixed(5)) : null;
const arr6 = a => a && a.length === NW ? Array.from(a, x => +x.toFixed(6)) : null;

function pack(st, extra = {}) {
  const thetaStand = st.thetaStand || st.theta;
  const bestStand = st.bestStand || st.bestTheta;
  return {
    H, NI, O, NW, nets: 2,
    gen: st.gen, A: st.A, Pm: st.Pm, Q: st.Q, Pa: st.Pa, G: st.G || 0,
    sig: st.sig, lr: st.lr,
    kStand: st.kStand || 0, kSupine: st.kSupine || 0, kProne: st.kProne || 0,
    hist: (st.hist || []).slice(-80),
    bestStandF: st.bestStandF, bestStandGen: st.bestStandGen,
    bestSupineF: st.bestSupineF, bestSupineGen: st.bestSupineGen,
    bestProneF: st.bestProneF, bestProneGen: st.bestProneGen,
    bestGetupF: st.bestSupineF, bestGetupGen: st.bestSupineGen,
    bestF: st.bestStandF, bestGen: st.bestStandGen,
    theta: arr5(thetaStand),
    bestTheta: arr5(bestStand),
    thetaStand: arr5(thetaStand),
    thetaGetup: arr5(st.thetaSupine),
    thetaSupine: arr5(st.thetaSupine),
    thetaProne: arr5(st.thetaProne),
    bestStand: arr5(bestStand),
    bestGetup: arr5(st.bestSupine),
    bestSupine: arr5(st.bestSupine),
    bestProne: arr5(st.bestProne),
    mStand: arr6(st.mStand), vStand: arr6(st.vStand),
    mSupine: arr6(st.mSupine), vSupine: arr6(st.vSupine),
    mProne: arr6(st.mProne), vProne: arr6(st.vProne),
    eval: st.lastEval || null,
    ...extra
  };
}

function save(st) {
  const full = pack(st);
  fs.writeFileSync(CKPT, JSON.stringify(full));
  const w = {
    H, NI, O, NW, nets: 2,
    gen: st.gen, bestGen: st.bestStandGen, bestStandGen: st.bestStandGen,
    bestSupineGen: st.bestSupineGen, bestProneGen: st.bestProneGen, bestGetupGen: st.bestSupineGen,
    eval: st.lastEval || null,
    hist: (st.hist || []).slice(-80),
    theta: full.theta, bestTheta: full.bestTheta,
    thetaStand: full.thetaStand, thetaGetup: full.thetaSupine,
    thetaSupine: full.thetaSupine, thetaProne: full.thetaProne,
    bestStand: full.bestStand, bestGetup: full.bestSupine,
    bestSupine: full.bestSupine, bestProne: full.bestProne
  };
  fs.writeFileSync(WEIGHTS, JSON.stringify(w));
}

function loadCkpt() {
  const c = JSON.parse(fs.readFileSync(CKPT, 'utf8'));
  const n = netsFromCkpt(c);
  const adam = (a) => padWeights(a) || new Float32Array(NW);
  return {
    thetaStand: n.thetaStand, thetaGetup: n.thetaSupine,
    thetaSupine: n.thetaSupine, thetaProne: n.thetaProne,
    theta: n.thetaStand,
    bestStand: n.bestStand, bestGetup: n.bestSupine,
    bestSupine: n.bestSupine, bestProne: n.bestProne,
    bestTheta: n.bestStand,
    gen: c.gen || 0, hist: c.hist || [], A: c.A ?? 0.12, Pm: c.Pm ?? 0, Q: c.Q ?? 0, Pa: c.Pa ?? 0,
    G: c.G ?? 0, sig: c.sig ?? 0.1, lr: c.lr ?? 0.01,
    kStand: n.migrated ? 0 : (c.kStand || 0),
    kSupine: n.padded ? 0 : (c.kSupine || 0),
    kProne: n.padded ? 0 : (c.kProne || 0),
    mStand: n.migrated ? new Float32Array(NW) : adam(c.mStand),
    vStand: n.migrated ? new Float32Array(NW) : adam(c.vStand),
    mSupine: n.padded ? new Float32Array(NW) : adam(c.mSupine),
    vSupine: n.padded ? new Float32Array(NW) : adam(c.vSupine),
    mProne: n.padded ? new Float32Array(NW) : adam(c.mProne),
    vProne: n.padded ? new Float32Array(NW) : adam(c.vProne),
    bestStandF: c.bestStandF ?? (n.migrated ? c.bestF : undefined),
    bestSupineF: c.bestSupineF ?? c.bestGetupF,
    bestProneF: c.bestProneF,
    bestStandGen: c.bestStandGen ?? (n.migrated ? c.bestGen : undefined),
    bestSupineGen: c.bestSupineGen ?? c.bestGetupGen,
    bestProneGen: c.bestProneGen,
    bestF: c.bestStandF ?? c.bestF, bestGen: c.bestStandGen ?? c.bestGen,
    lastEval: c.eval || null,
    migrated: n.migrated, padded: n.padded
  };
}

function makePool() {
  const workers = [];
  const wait = new Map();
  let nextId = 1;
  function spawn(i) {
    return new Promise((res, rej) => {
      const w = new Worker(path.join(__dirname, 'worker.js'), { workerData: { seed: 1000 + i } });
      const to = setTimeout(() => rej(new Error('worker timeout')), 25000);
      w.on('message', m => {
        if (m.type === 'ready') { clearTimeout(to); res({ w }); return; }
        if (m.type === 'done') {
          const p = wait.get(m.id);
          if (p) { wait.delete(m.id); p.res(m.out); }
        }
      });
      w.on('error', e => { clearTimeout(to); rej(e); });
    });
  }
  async function ready() {
    workers.push(...await Promise.all(Array.from({ length: K }, (_, i) => spawn(i))));
  }
  function evalItems(items) {
    if (!items.length) return Promise.resolve([]);
    const buckets = Array.from({ length: K }, () => []);
    items.forEach((it, i) => buckets[i % K].push({ i, w: Array.from(it.w), o: it.o }));
    return Promise.all(buckets.map((b, k) => {
      if (!b.length) return [];
      const id = nextId++;
      return new Promise((res, rej) => {
        const to = setTimeout(() => { wait.delete(id); rej(new Error('eval timeout')); }, 180000);
        wait.set(id, { res: out => { clearTimeout(to); res(out); }, rej });
        workers[k].w.postMessage({ type: 'eval', id, tasks: b });
      });
    })).then(rs => {
      const out = new Array(items.length);
      for (const r of rs.flat()) if (r) out[r.i] = r;
      if (out.some(x => !x || !Number.isFinite(x.f))) throw new Error('incomplete eval batch');
      return out;
    });
  }
  function kill() { for (const { w } of workers) w.terminate(); }
  return { ready, evalItems, kill };
}

function evalSuite() {
  const er = rngMk(4242);
  const supine = [], prone = [];
  const base = { push: 0, amp: 0, T: 8, ph: 0, proj: [], task: 'getup', steps: 960, full: true };
  for (let i = 0; i < 3; i++) {
    const s = S.supinePose(er), p = S.pronePose(er);
    supine.push({ ...base, tilt: s.tilt, drop: s.drop });
    prone.push({ ...base, tilt: p.tilt, drop: p.drop });
  }
  return { supine, prone };
}

function summarize(label, rows) {
  const n = rows.length || 1;
  const avg = k => rows.reduce((a, b) => a + (b[k] || 0), 0) / n;
  return {
    f: avg('f'),
    rec: rows.filter(r => r.rec).length / n,
    up: rows.filter(r => r.up).length / n,
    hy: avg('hy'),
    stood: avg('stood'),
    ang: avg('ang'),
    hand: avg('hand'),
    label
  };
}

function getupScore(ev) {
  return 0.5 * ev.supine.rec + 0.5 * ev.prone.rec;
}

const EV = evalSuite();

async function runEval(pool, nets) {
  const supine = await pool.evalItems(EV.supine.map(o => ({ w: nets.thetaSupine || nets.thetaGetup || nets.theta, o })));
  const prone = await pool.evalItems(EV.prone.map(o => ({ w: nets.thetaProne || nets.thetaGetup || nets.theta, o })));
  const ev = { supine: summarize('supine', supine), prone: summarize('prone', prone) };
  ev.getup = ev.supine;
  ev.score = getupScore(ev);
  ev.getupScore = ev.score;
  return ev;
}

function fmtEv(ev) {
  const p = (x) => (100 * x).toFixed(0) + '%';
  const s = ev.supine, pr = ev.prone;
  return `supine rec ${p(s.rec)} hy ${s.hy.toFixed(2)}  prone rec ${p(pr.rec)} hy ${pr.hy.toFixed(2)}`;
}

const pool = makePool();
let st = resume ? loadCkpt() : S.freshState();
if (resume && st.A >= 0.35) {
  st.Pa = Math.max(st.Pa || 0, 0.85);
}
if (resume && !resetGetup && st.bestStand && (st.lastEval?.stand?.stood ?? 1) < 0.75) {
  st.thetaStand = st.bestStand.slice();
  st.theta = st.thetaStand;
}
if (resume && resetGetup) {
  st.thetaSupine = S.initTheta();
  st.thetaProne = S.initTheta();
  st.thetaGetup = st.thetaSupine;
  st.bestSupine = null; st.bestProne = null; st.bestGetup = null;
  st.bestSupineF = undefined; st.bestProneF = undefined;
  st.bestSupineGen = undefined; st.bestProneGen = undefined;
  st.mSupine = new Float32Array(NW); st.vSupine = new Float32Array(NW); st.kSupine = 0;
  st.mProne = new Float32Array(NW); st.vProne = new Float32Array(NW); st.kProne = 0;
  st.G = 0;
  st.lastEval = null;
}
let stopping = false;
process.on('SIGINT', () => { stopping = true; log('SIGINT: saving after this gen'); });
process.on('SIGTERM', () => { stopping = true; });

await pool.ready();
log(`pool ${K} workers  NP ${NP}  NW ${NW}  max ${maxGens}  curriculum getup supine+prone  ${resume ? 'resume gen ' + st.gen : 'fresh'}${st.migrated ? '  migrate two-net from bestTheta' : ''}${resetGetup ? '  getup reset  stand kept' : ''}${st.padded ? '  inputs padded' : ''}`);
if (!resume || resetGetup || st.padded) save(st);

if (evalOnly) {
  const ev = await runEval(pool, {
    thetaStand: st.bestStand || st.thetaStand,
    thetaSupine: st.bestSupine || st.thetaSupine,
    thetaProne: st.bestProne || st.thetaProne
  });
  log('eval ' + fmtEv(ev));
  pool.kill();
  process.exit(0);
}

const t0 = Date.now();
let bestSupineScore = -1, bestProneScore = -1;

function keepPose(score, evRec, theta, gen, key) {
  if (score < 0 || evRec >= score - 0.002) {
    const f = Math.max(score, evRec);
    st['best' + key + 'F'] = f;
    st['best' + key + 'Gen'] = gen;
    st['best' + key] = theta.slice();
    return f;
  }
  return score;
}

{
  const ev = await runEval(pool, st);
  st.lastEval = ev;
  log('start ' + fmtEv(ev) + (st.bestStandGen != null ? `  bestStand gen ${st.bestStandGen} kept` : ''));
  if (resume && st.bestSupine && st.bestSupineF != null) bestSupineScore = st.bestSupineF;
  if (resume && st.bestProne && st.bestProneF != null) bestProneScore = st.bestProneF;
  bestSupineScore = keepPose(bestSupineScore, ev.supine.rec, st.thetaSupine, st.gen, 'Supine');
  bestProneScore = keepPose(bestProneScore, ev.prone.rec, st.thetaProne, st.gen, 'Prone');
  st.bestGetupF = st.bestSupineF; st.bestGetupGen = st.bestSupineGen; st.bestGetup = st.bestSupine;
  st.bestF = st.bestStandF; st.bestGen = st.bestStandGen; st.bestTheta = st.bestStand;
  st.theta = st.thetaStand;
  save(st);
}

while (!stopping && st.gen < maxGens) {
  const tGen = Date.now();
  const pop = S.esAsk(st, NP);
  const fits = await pool.evalItems(pop.ws.map(w => ({ w, o: pop.o })));
  S.esTell(st, pop, fits);
  const last = st.hist[st.hist.length - 1];
  const dt = ((Date.now() - tGen) / 1000).toFixed(1);
  log(`gen ${st.gen}  getup ${pop.o.pose} tilt ${pop.o.tilt.toFixed(2)}  fit ${last.m.toFixed(2)}/${last.b.toFixed(2)}  up ${(100 * last.s).toFixed(0)}%  |a| ${(last.ang || 0).toFixed(0)}° hand ${(100 * (last.hand || 0)).toFixed(0)}% hy ${(last.hy || 0).toFixed(2)}  ${dt}s`);
  if (st.gen % 15 === 0) {
    const ev = await runEval(pool, st);
    st.lastEval = ev;
    log('eval ' + fmtEv(ev));
    if (ev.supine.rec >= bestSupineScore - 0.002) bestSupineScore = keepPose(bestSupineScore, ev.supine.rec, st.thetaSupine, st.gen, 'Supine');
    if (ev.prone.rec >= bestProneScore - 0.002) bestProneScore = keepPose(bestProneScore, ev.prone.rec, st.thetaProne, st.gen, 'Prone');
    st.bestGetupF = st.bestSupineF; st.bestGetupGen = st.bestSupineGen; st.bestGetup = st.bestSupine;
    st.bestF = st.bestStandF; st.bestGen = st.bestStandGen; st.bestTheta = st.bestStand;
    st.theta = st.thetaStand;
    st.sig = Math.max(0.055, 0.1 * Math.pow(0.5, st.gen / 5500));
  }
  save(st);
}

save(st);
log(`done gen ${st.gen} bestStand ${st.bestStandGen} bestSupine ${st.bestSupineGen} ${bestSupineScore.toFixed(3)} bestProne ${st.bestProneGen} ${bestProneScore.toFixed(3)}  ${(Date.now() - t0) / 60000} min`);
pool.kill();
process.exit(0);
